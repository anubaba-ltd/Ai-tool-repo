(() => {
  'use strict';
  const PORTAL_LOGIN = 'https://aianubaba.co.uk/login?extension=required';
  let denied = false;
  let transientMisses = 0;

  function blockAndReturnToPortal() {
    if (denied) return;
    denied = true;
    try {
      document.documentElement.style.visibility = 'hidden';
      document.documentElement.style.pointerEvents = 'none';
    } catch (_) {}
    try { window.location.replace(PORTAL_LOGIN); } catch (_) { window.location.href = PORTAL_LOGIN; }
  }

  async function heartbeat(reason, force = true) {
    if (denied) return;
    try {
      const result = await chrome.runtime.sendMessage({ action: 'heartbeat', reason, force });
      if (result?.ok) {
        transientMisses = 0;
        return;
      }
      if (result?.transient) {
        transientMisses += 1;
        if (transientMisses < 3) return;
      }
      blockAndReturnToPortal();
    } catch (_) {
      blockAndReturnToPortal();
    }
  }

  heartbeat('flow-document-start-refresh', true);
  window.addEventListener('pageshow', () => heartbeat('flow-pageshow', true), true);
  window.addEventListener('focus', () => heartbeat('flow-focus', true), true);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') heartbeat('flow-visible', true);
  }, true);
  setInterval(() => heartbeat('flow-5sec', true), 5000);
})();
