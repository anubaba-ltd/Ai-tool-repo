(() => {
  'use strict';
  const PAGE_SOURCE = 'AIANUBABA_PORTAL';
  const EXT_SOURCE = 'AIANUBABA_EXTENSION';

  function reply(requestId, payload) {
    window.postMessage({ source: EXT_SOURCE, type: 'RESPONSE', requestId, payload }, window.location.origin);
  }

  async function sendRuntime(message) {
    try {
      return await chrome.runtime.sendMessage(message);
    } catch (e) {
      return { ok: false, code: 'EXTENSION_CONTEXT_INVALID', error: e?.message || 'Extension context unavailable.' };
    }
  }

  window.addEventListener('message', async (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const data = event.data || {};
    if (data.source !== PAGE_SOURCE || !data.requestId) return;

    let result;
    switch (data.type) {
      case 'PRESENCE':
        result = await sendRuntime({ action: 'presence' });
        break;
      case 'ACTIVATE':
        result = await sendRuntime({ action: 'activateFromPortal', activationToken: data.payload?.activationToken });
        break;
      case 'HEARTBEAT':
        result = await sendRuntime({ action: 'heartbeat', reason: data.payload?.reason || 'portal-5sec', force: !!data.payload?.force });
        break;
      case 'STATUS':
        result = await sendRuntime({ action: 'getAuthStatus' });
        break;
      case 'LAUNCH':
        result = await sendRuntime({ action: 'launch', url: data.payload?.url });
        break;
      case 'LOGOUT_EXTENSION':
        result = await sendRuntime({ action: 'logoutExtension' });
        break;
      default:
        result = { ok: false, code: 'UNKNOWN_PORTAL_MESSAGE' };
    }
    reply(data.requestId, result);
  }, false);

  // Refresh/page-load heartbeat. This is in addition to the website checker.
  sendRuntime({ action: 'heartbeat', reason: 'portal-page-load-refresh', force: true }).then((payload) => {
    window.postMessage({ source: EXT_SOURCE, type: 'AUTH_EVENT', payload }, window.location.origin);
  });

})();
