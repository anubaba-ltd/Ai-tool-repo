# ABL PRO AI Tools

ABL PRO AI Tools is a customized local developer cookie editor build.

Features:
- View cookies for the current website
- Add, edit, and delete cookies
- Delete all current-site cookies
- Import cookies by directly pasting JSON
- Export cookies as JSON text for copying

Install:
1. Extract this ZIP file.
2. Open Chrome and go to `chrome://extensions`.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select the extracted `awan-pro-cookie-editor` folder.

Use only for your own development/testing accounts and websites. Cookie data can contain sensitive login/session information.

Attribution: this customized build is based on the open-source Cookie-Editor project and keeps the included GPL-3.0 license file.


Update 1.13.4: More prominent ABL PRO AI Tools watermark inside import/export text boxes.


Version 1.13.5: Clean watermark fix. Uses one centered ABL PRO AI Tools logo in the import/export text area without duplicate ghosting.


Version 1.15.1: Final ABL PRO AI Tools build with premium clearer logo assets and strict Flow four-model guard.
