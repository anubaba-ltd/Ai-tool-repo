(() => {
  "use strict";

  const TOAST_ID = "abl-pro-flow-toast";

  const ALLOWED_MODELS = [
    "Veo 3.1 - Lite [Lower Priority]",
    "Nano Banana 2",
    "Nano Banana Pro",
    "Imagen 4"
  ];

  const ALL_MODEL_TEXTS = [
    "Omni Flash",
    "Veo 3.1 - Lite",
    "Veo 3.1 - Fast",
    "Veo 3.1 - Quality",
    "Veo 3.1 - Lite [Lower Priority]",
    "Nano Banana",
    "Nano Banana 2",
    "Nano Banana Pro",
    "Imagen 4"
  ];

  const SUBMIT_SELECTOR =
    ".sc-e8425ea6-0.hOBPaw.sc-d3791a4f-0.sc-d3791a4f-4.sc-439ac1d3-5.ewGlDn.famhRe.iIhbxv";

  let selectedModel = "";
  let planData = null;

  function cleanText(text) {
    return String(text || "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function isAllowedModel(model) {
    return ALLOWED_MODELS.includes(model);
  }

  function getSubmitButton() {
    const exactButton = document.querySelector(SUBMIT_SELECTOR);
    if (exactButton) return exactButton;

    const buttons = [...document.querySelectorAll("button, [role='button']")];

    return buttons.find((btn) => {
      const text = cleanText(btn.innerText || btn.textContent || btn.getAttribute("aria-label"));
      return /generate|submit|create|send|start/i.test(text);
    }) || null;
  }

  function showToast(message) {
    let toast = document.getElementById(TOAST_ID);

    if (!toast) {
      toast = document.createElement("div");
      toast.id = TOAST_ID;

      toast.style.cssText = `
        position: fixed;
        top: 18px;
        right: 18px;
        z-index: 999999999;
        max-width: 430px;
        padding: 14px 18px;
        border-radius: 12px;
        background: linear-gradient(135deg, rgba(2, 35, 50, 0.97), rgba(0, 88, 110, 0.97));
        color: #ffffff;
        font-family: Arial, sans-serif;
        font-size: 14px;
        font-weight: 800;
        line-height: 1.5;
        border: 1px solid rgba(0, 200, 255, 0.75);
        box-shadow: 0 12px 35px rgba(0, 0, 0, 0.45);
        pointer-events: none;
        opacity: 0;
        transition: opacity 0.25s ease;
      `;

      document.body.appendChild(toast);
    }

    toast.textContent =
      message ||
      "Please use Veo 3.1 Lite Low Priority, Nano Banana 2, Nano Banana Pro, or Imagen 4 only.";

    toast.style.opacity = "1";

    clearTimeout(window.ablProToastTimer);
    window.ablProToastTimer = setTimeout(() => {
      toast.style.opacity = "0";
    }, 3500);
  }

  function isPlanExpired() {
    if (!planData) return false;

    const days = Number(planData.daysRemaining ?? planData.extension2_days ?? 1);
    const expires =
      planData.planExpiresAt ||
      planData.planExpires ||
      planData.extension2_expiry;

    if (!Number.isNaN(days) && days <= 0) return true;
    if (expires && new Date(expires).getTime() < Date.now()) return true;

    return false;
  }

  function blockSubmit() {
    const btn = getSubmitButton();
    if (!btn) return;

    if (!btn.dataset.ablModelBlocked) {
      btn.dataset.ablModelBlocked = "true";
      btn.dataset.ablPrevDisabled = btn.disabled ? "true" : "false";
      btn.dataset.ablPrevAria = btn.getAttribute("aria-disabled") || "";
    }

    btn.disabled = true;
    btn.setAttribute("aria-disabled", "true");
    btn.style.opacity = "0.35";
    btn.style.cursor = "not-allowed";
    btn.style.filter = "grayscale(1)";
  }

  function unblockSubmit() {
    const btn = getSubmitButton();
    if (!btn) return;

    if (btn.dataset.ablModelBlocked === "true") {
      btn.disabled = btn.dataset.ablPrevDisabled === "true";

      if (btn.dataset.ablPrevAria) {
        btn.setAttribute("aria-disabled", btn.dataset.ablPrevAria);
      } else {
        btn.removeAttribute("aria-disabled");
      }

      delete btn.dataset.ablModelBlocked;
      delete btn.dataset.ablPrevDisabled;
      delete btn.dataset.ablPrevAria;
    }

    btn.style.opacity = "";
    btn.style.cursor = "";
    btn.style.filter = "";
  }

  function findSelectedModelFromClosedDropdown() {
    const buttons = [...document.querySelectorAll("button")];

    for (const btn of buttons) {
      const text = cleanText(btn.innerText || btn.textContent || "");

      if (
        text.includes("Video") ||
        text.includes("Image") ||
        text.includes("Frames") ||
        text.includes("Ingredients") ||
        text.includes("4s") ||
        text.includes("6s") ||
        text.includes("8s") ||
        text.includes("9:16") ||
        text.includes("16:9") ||
        text.includes("1x") ||
        text.includes("2x") ||
        text.includes("3x") ||
        text.includes("4x")
      ) {
        continue;
      }

      // Allowed models first
      for (const allowed of ALLOWED_MODELS) {
        if (text.includes(allowed)) return allowed;
      }

      // Then blocked/other models
      for (const model of ALL_MODEL_TEXTS) {
        if (text.includes(model)) return model;
      }
    }

    return selectedModel;
  }

  function updateSelectedModelFromClickText(text) {
    text = cleanText(text);

    // Allowed models first
    if (text.includes("Veo 3.1 - Lite [Lower Priority]")) {
      selectedModel = "Veo 3.1 - Lite [Lower Priority]";
      return;
    }

    if (text.includes("Nano Banana 2")) {
      selectedModel = "Nano Banana 2";
      return;
    }

    if (text.includes("Nano Banana Pro")) {
      selectedModel = "Nano Banana Pro";
      return;
    }

    if (text.includes("Imagen 4")) {
      selectedModel = "Imagen 4";
      return;
    }

    // Blocked models
    if (text.includes("Omni Flash")) {
      selectedModel = "Omni Flash";
      return;
    }

    if (text.includes("Veo 3.1 - Quality")) {
      selectedModel = "Veo 3.1 - Quality";
      return;
    }

    if (text.includes("Veo 3.1 - Fast")) {
      selectedModel = "Veo 3.1 - Fast";
      return;
    }

    if (text.includes("Veo 3.1 - Lite") && !text.includes("Lower Priority")) {
      selectedModel = "Veo 3.1 - Lite";
      return;
    }

    if (
      text.includes("Nano Banana") &&
      !text.includes("Nano Banana 2") &&
      !text.includes("Nano Banana Pro")
    ) {
      selectedModel = "Nano Banana";
    }
  }

  function updateSubmitState() {
    selectedModel = findSelectedModelFromClosedDropdown();

    if (isPlanExpired()) {
      blockSubmit();
      return;
    }

    if (isAllowedModel(selectedModel)) {
      unblockSubmit();
      return;
    }

    // Strict mode: if model is unknown or not allowed, keep submit blocked.
    blockSubmit();
  }

  function loadPlanData() {
    try {
      chrome.storage.local.get(["flowGuardPlan"], (result) => {
        planData = result.flowGuardPlan || null;
        updateSubmitState();
      });
    } catch (_) {}
  }

  document.addEventListener(
    "click",
    function (e) {
      const clicked = e.target.closest("button, div, span");
      const text = cleanText(clicked?.innerText || clicked?.textContent || "");

      updateSelectedModelFromClickText(text);

      const submitBtn = getSubmitButton();

      if (
        submitBtn &&
        submitBtn.contains(e.target) &&
        (!isAllowedModel(selectedModel) || isPlanExpired())
      ) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        blockSubmit();

        showToast(
          "Please use Veo 3.1 Lite Low Priority, Nano Banana 2, Nano Banana Pro, or Imagen 4 only."
        );

        return false;
      }

      setTimeout(updateSubmitState, 100);
      setTimeout(updateSubmitState, 400);
      setTimeout(updateSubmitState, 1000);
    },
    true
  );

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.flowGuardPlan) {
        planData = changes.flowGuardPlan.newValue || null;
        updateSubmitState();
      }
    });
  } catch (_) {}

  const observer = new MutationObserver(() => {
    updateSubmitState();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true
  });

  loadPlanData();
  updateSubmitState();

  setInterval(updateSubmitState, 1200);

  console.log("ABL PRO AI Tools Flow Guard active. Allowed models:", ALLOWED_MODELS);
})();