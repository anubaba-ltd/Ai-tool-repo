const btn = document.getElementById('btn');
const msg = document.getElementById('msg');
const timerBox = document.getElementById('timerBox');
const countdown = document.getElementById('countdown');
const account = document.getElementById('account');
const securityBadge = document.getElementById('securityBadge');
let active = false;
let timer = null;

function show(text, type) { msg.textContent = text; msg.className = `msg ${type}`; }
function formatTime(ms) {
  if (ms <= 0) return '0:00:00';
  const h = Math.floor(ms / 3600000), m = Math.floor((ms % 3600000) / 60000), s = Math.floor((ms % 60000) / 1000);
  return `${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
}
async function refreshStatus(forceHeartbeat = false) {
  let status = await chrome.runtime.sendMessage({ action: 'getAuthStatus' });
  if (status?.active && forceHeartbeat) {
    const hb = await chrome.runtime.sendMessage({ action: 'heartbeat', reason: 'popup-open', force: true });
    if (!hb?.ok && !hb?.transient) status = { active: false };
  }
  active = !!status?.active;
  account.textContent = status?.user?.email || 'Not linked';
  securityBadge.textContent = active ? '✓ Protected' : 'Not linked';
  securityBadge.className = active ? 'badge' : 'badge off';
  btn.textContent = active ? '🚀 Launch AI Tools' : '🔐 Open Portal & Login';
  timerBox.style.display = active ? 'block' : 'none';
  if (timer) clearInterval(timer);
  if (active) {
    const render = () => {
      const ms = Math.max(0, new Date(status.expiresAt || 0).getTime() - Date.now());
      countdown.textContent = formatTime(ms);
      countdown.style.color = ms < 900000 ? '#f07070' : '#70a8f0';
      if (ms <= 0) { clearInterval(timer); refreshStatus(false); }
    };
    render(); timer = setInterval(render, 1000);
    show('✅ Portal account linked. Heartbeat is active every 5 seconds.', 'ok');
  } else {
    show('Login to aianubaba.co.uk. The extension will link automatically from your dashboard.', 'inf');
  }
}
window.addEventListener('load', () => refreshStatus(true));
btn.addEventListener('click', async () => {
  btn.disabled = true;
  try {
    if (!active) {
      await chrome.tabs.create({ url: 'https://aianubaba.co.uk/login', active: true });
      window.close(); return;
    }
    show('🔐 Verifying server session...', 'inf');
    const r = await chrome.runtime.sendMessage({ action: 'launch', url: 'https://labs.google/fx/tools/flow' });
    if (r?.ok) show('✅ Access verified. Launching AI Tools...', 'ok');
    else if (r?.transient) show('⚠ Portal heartbeat temporarily unavailable. Please try again.', 'err');
    else { show(`❌ ${r?.error || 'Session is not active.'}`, 'err'); active = false; await refreshStatus(false); }
  } finally { btn.disabled = false; }
});
