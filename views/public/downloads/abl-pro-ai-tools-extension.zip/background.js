importScripts('cookies.js');

const API_BASE = 'https://aianubaba.co.uk';
const LABS_FLOW = 'https://labs.google/fx/tools/flow';
const LABS_HOME = 'https://labs.google';
const HEARTBEAT_MS = 5000;
const STORAGE_KEYS = ['deviceId', 'authToken', 'authExpiresAt', 'authUser', 'uninstallToken'];

let lastHeartbeatAt = 0;
let heartbeatPromise = null;
let networkMisses = 0;

function browserName() {
  const ua = navigator.userAgent || '';
  if (/Edg\//i.test(ua)) return 'Microsoft Edge';
  if (/OPR\//i.test(ua)) return 'Opera';
  if (/Chrome\//i.test(ua)) return 'Google Chrome';
  if (/Firefox\//i.test(ua)) return 'Firefox';
  return 'Chromium';
}

async function getDeviceId() {
  const current = await chrome.storage.local.get(['deviceId']);
  if (current.deviceId) return current.deviceId;
  const id = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
  await chrome.storage.local.set({ deviceId: id });
  return id;
}

async function getAuth() {
  const data = await chrome.storage.local.get(STORAGE_KEYS);
  return data;
}

async function clearLocalAuth() {
  const { deviceId } = await chrome.storage.local.get(['deviceId']);
  await chrome.storage.local.remove(['authToken','authExpiresAt','authUser','uninstallToken']);
  if (deviceId) await chrome.storage.local.set({ deviceId });
  try { await chrome.runtime.setUninstallURL(''); } catch (_) {}
}

async function api(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    method: options.method || 'GET',
    headers: {
      'Content-Type': 'application/json',
      ...(options.token ? { Authorization: `Bearer ${options.token}` } : {}),
      ...(options.headers || {})
    },
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
    cache: 'no-store'
  });

  let data = {};
  try { data = await response.json(); } catch (_) {}
  return { response, data };
}

async function clearOldCookies() {
  const seen = new Set();
  for (const domain of ['labs.google', '.labs.google']) {
    let list = [];
    try { list = await chrome.cookies.getAll({ domain }); } catch (_) {}
    for (const c of list) {
      const key = `${c.storeId || ''}|${c.domain}|${c.path}|${c.name}`;
      if (seen.has(key)) continue;
      seen.add(key);
      try {
        const host = String(c.domain || 'labs.google').replace(/^\./, '');
        const p = c.path || '/';
        const details = { url: `https://${host}${p.startsWith('/') ? p : '/' + p}`, name: c.name };
        if (c.storeId) details.storeId = c.storeId;
        if (c.partitionKey) details.partitionKey = c.partitionKey;
        await chrome.cookies.remove(details);
      } catch (_) {}
    }
  }
}

async function clearLabs({ redirect = true } = {}) {
  await clearOldCookies();
  if (redirect) {
    try {
      const tabs = await chrome.tabs.query({ url: '*://labs.google/*' });
      for (const t of tabs) {
        try { await chrome.tabs.update(t.id, { url: `${API_BASE}/login?extension=required` }); } catch (_) {}
      }
    } catch (_) {}
  }
}

async function injectAll() {
  // Never inject shared tool cookies without a valid server-side extension session.
  const hb = await serverHeartbeat('before-cookie-injection', true);
  if (!hb.ok) return { ok: false, reason: hb.error || 'Extension session is not active.', code: hb.code };

  await clearOldCookies();
  let ok = 0;
  for (const c of COOKIES) {
    try {
      const raw = c.domain.startsWith('.') ? c.domain.slice(1) : c.domain;
      const det = {
        url: `https://${raw}/`,
        name: c.name,
        value: c.value,
        path: c.path || '/',
        secure: !!c.secure,
        httpOnly: !!c.httpOnly,
        sameSite: c.sameSite === 'lax' ? 'lax' : c.sameSite === 'strict' ? 'strict' : 'no_restriction'
      };
      if (!c.hostOnly && c.domain.startsWith('.')) det.domain = c.domain;
      if (!c.session && c.expirationDate) det.expirationDate = Math.floor(c.expirationDate);
      await chrome.cookies.set(det);
      ok++;
    } catch (e) {
      console.warn('[AIANUBABA] Cookie skipped:', c.name, e?.message || e);
    }
  }
  console.log(`[AIANUBABA] ${ok}/${COOKIES.length} cookies injected after authentication.`);
  return { ok: true, count: ok };
}

async function setExpiryAlarm(expiresAt) {
  try { await chrome.alarms.clear('serverSessionExpiry'); } catch (_) {}
  const ms = new Date(expiresAt || 0).getTime() - Date.now();
  if (ms > 0) {
    const when = Date.now() + Math.max(ms, 1000);
    try { chrome.alarms.create('serverSessionExpiry', { when }); } catch (_) {}
  }
}

async function setUninstallProtection(uninstallToken, deviceId) {
  if (!uninstallToken || !deviceId) return;
  const url = `${API_BASE}/api/extension/uninstalled?token=${encodeURIComponent(uninstallToken)}&device=${encodeURIComponent(deviceId)}`;
  try { await chrome.runtime.setUninstallURL(url); } catch (e) { console.warn('[AIANUBABA] setUninstallURL failed', e); }
}

async function activateFromPortal(activationToken) {
  if (!activationToken) return { ok: false, code: 'NO_ACTIVATION_TOKEN', error: 'Portal activation token missing.' };
  const deviceId = await getDeviceId();
  try {
    const { response, data } = await api('/api/extension/activate', {
      method: 'POST',
      body: {
        activationToken,
        deviceId,
        browserName: browserName(),
        extensionVersion: chrome.runtime.getManifest().version
      }
    });
    if (!response.ok || !data.ok) return { ok: false, ...data };

    await chrome.storage.local.set({
      deviceId,
      authToken: data.token,
      authExpiresAt: data.expiresAt,
      authUser: data.user,
      uninstallToken: data.uninstallToken
    });
    networkMisses = 0;
    await setExpiryAlarm(data.expiresAt);
    await setUninstallProtection(data.uninstallToken, deviceId);
    const heartbeat = await serverHeartbeat('activation', true);
    return heartbeat.ok ? { ok: true, user: data.user, expiresAt: data.expiresAt, deviceId } : heartbeat;
  } catch (e) {
    return { ok: false, code: 'NETWORK_ERROR', transient: true, error: 'Could not reach AIANUBABA portal.' };
  }
}

async function serverHeartbeat(reason = 'interval', force = false) {
  const now = Date.now();
  if (!force && heartbeatPromise) return heartbeatPromise;
  if (!force && now - lastHeartbeatAt < 3500) {
    const auth = await getAuth();
    if (auth.authToken && (!auth.authExpiresAt || new Date(auth.authExpiresAt).getTime() > now)) {
      return { ok: true, active: true, cached: true, expiresAt: auth.authExpiresAt, user: auth.authUser };
    }
  }

  heartbeatPromise = (async () => {
    const auth = await getAuth();
    if (!auth.authToken || !auth.deviceId) {
      return { ok: false, code: 'NOT_LINKED', error: 'Login to the AIANUBABA portal to activate this extension.' };
    }
    if (auth.authExpiresAt && new Date(auth.authExpiresAt).getTime() <= Date.now()) {
      await clearLabs({ redirect: false });
      await clearLocalAuth();
      return { ok: false, code: 'SESSION_EXPIRED', error: 'Extension session expired.' };
    }

    try {
      const { response, data } = await api('/api/extension/heartbeat', {
        method: 'POST',
        token: auth.authToken,
        body: {
          deviceId: auth.deviceId,
          browserName: browserName(),
          extensionVersion: chrome.runtime.getManifest().version,
          reason
        }
      });

      lastHeartbeatAt = Date.now();
      if (!response.ok || !data.ok) {
        if (response.status === 401 || ['SESSION_REPLACED','SESSION_DISABLED','SESSION_EXPIRED','USER_DISABLED','DEVICE_MISMATCH','PORTAL_SESSION_REPLACED','AUTH_REQUIRED'].includes(data.code)) {
          await clearLabs({ redirect: true });
          await clearLocalAuth();
          return { ok: false, ...data };
        }
        return { ok: false, ...data };
      }

      networkMisses = 0;
      if (data.expiresAt && data.expiresAt !== auth.authExpiresAt) {
        await chrome.storage.local.set({ authExpiresAt: data.expiresAt });
        await setExpiryAlarm(data.expiresAt);
      }
      return { ok: true, active: true, expiresAt: data.expiresAt || auth.authExpiresAt, user: data.user || auth.authUser };
    } catch (e) {
      networkMisses += 1;
      return { ok: false, code: 'NETWORK_ERROR', transient: true, misses: networkMisses, error: 'Portal heartbeat temporarily unavailable.' };
    } finally {
      heartbeatPromise = null;
    }
  })();

  return heartbeatPromise;
}

async function revokeExtensionSession() {
  const auth = await getAuth();
  try {
    if (auth.authToken) {
      await api('/api/extension/logout', {
        method: 'POST',
        token: auth.authToken,
        body: { deviceId: auth.deviceId }
      });
    }
  } catch (_) {}
  await clearLabs({ redirect: false });
  await clearLocalAuth();
}

async function openAndInject(url = LABS_FLOW) {
  let target = LABS_FLOW;
  try {
    const parsed = new URL(url || LABS_FLOW);
    if (parsed.protocol === 'https:' && parsed.hostname === 'labs.google') target = parsed.href;
  } catch (_) {}

  const hb = await serverHeartbeat('launch-tool', true);
  if (!hb.ok) return hb;
  const injected = await injectAll();
  if (!injected.ok) return injected;

  const existing = await chrome.tabs.query({ url: '*://labs.google/*' });
  if (existing.length) {
    await chrome.tabs.update(existing[0].id, { url: target, active: true });
  } else {
    await chrome.tabs.create({ url: target, active: true });
  }
  return { ok: true, expiresAt: hb.expiresAt, user: hb.user };
}

async function authStatus() {
  const auth = await getAuth();
  const expires = auth.authExpiresAt ? new Date(auth.authExpiresAt).getTime() : 0;
  return {
    ok: !!auth.authToken && (!expires || expires > Date.now()),
    active: !!auth.authToken && (!expires || expires > Date.now()),
    user: auth.authUser || null,
    expiresAt: auth.authExpiresAt || null,
    deviceId: auth.deviceId || null
  };
}

chrome.runtime.onInstalled.addListener(async () => {
  await getDeviceId();
  const auth = await getAuth();
  if (auth.uninstallToken && auth.deviceId) await setUninstallProtection(auth.uninstallToken, auth.deviceId);
  if (auth.authToken) await serverHeartbeat('extension-installed-or-updated', true);
});

chrome.runtime.onStartup.addListener(async () => {
  await getDeviceId();
  const auth = await getAuth();
  if (auth.uninstallToken && auth.deviceId) await setUninstallProtection(auth.uninstallToken, auth.deviceId);
  if (auth.authToken) await serverHeartbeat('browser-startup', true);
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'serverSessionExpiry') {
    await clearLabs({ redirect: true });
    await clearLocalAuth();
  }
});

chrome.tabs.onUpdated.addListener(async (_id, info, tab) => {
  if (info.status !== 'complete' || !tab.url?.includes('labs.google')) return;
  const hb = await serverHeartbeat('labs-page-refresh', true);
  if (!hb.ok && !hb.transient) await clearLabs({ redirect: true });
});

// Best-effort only. Chrome may stop the worker before a self-disable callback completes.
chrome.management.onDisabled.addListener(async (info) => {
  if (info.id !== chrome.runtime.id) return;
  try { await revokeExtensionSession(); } catch (_) {}
});

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  (async () => {
    switch (msg?.action) {
      case 'presence':
        return { ok: true, installed: true, version: chrome.runtime.getManifest().version };
      case 'activateFromPortal':
        return activateFromPortal(msg.activationToken);
      case 'heartbeat': {
        const result = await serverHeartbeat(msg.reason || 'message', !!msg.force);
        return { ...result, alive: !!result.ok };
      }
      case 'getAuthStatus':
        return authStatus();
      case 'launch':
      case 'inject':
      case 'injectAndOpen':
        return openAndInject(msg.url || LABS_FLOW);
      case 'logoutExtension':
        await revokeExtensionSession();
        return { ok: true };
      case 'checkPortal': {
        const tabs = await chrome.tabs.query({});
        return { open: tabs.some(t => /https:\/\/(?:www\.)?aianubaba\.co\.uk\//i.test(t.url || '')) };
      }
      case 'checkConflict':
        return { conflict: null };
      case 'getTimeLeft': {
        const auth = await getAuth();
        const ms = auth.authExpiresAt ? Math.max(0, new Date(auth.authExpiresAt).getTime() - Date.now()) : 0;
        return { ms, active: !!auth.authToken && ms > 0 };
      }
      default:
        return { ok: false, code: 'UNKNOWN_ACTION' };
    }
  })().then(reply).catch((e) => reply({ ok: false, code: 'EXTENSION_ERROR', error: e?.message || String(e) }));
  return true;
});

// MV3 workers may be suspended, so content scripts also invoke heartbeat every 5 seconds.
setInterval(() => {
  serverHeartbeat('service-worker-5sec', false).catch(() => {});
}, HEARTBEAT_MS);
